# REPLAPI Module
##### Replit stats module
#### Made by [@JBYT27](github.com/JBYT27) & [@darkdarcool](github.com/darkdarcool)

--- 

## About module
#### Welcome to the REPLAPI module! (pronounced "rep"-"l"-"a"-"p"-"i")

#### This module allows you to access info (not personal) from all over replit. This would include:
+ Username & Nickname
+ Bio
+ Cycles/Karma
+ Common langs
+ Posts and comments (coming soon)

#### It is currently accessible on PYPI, but it may have bugs. 
###### [This is the link](https://pypi.org/project/REPLAPI/)

--- 

## Version
#### VERSION 0.0.1 IS OUT!! IT IS VERY LAGGY, AS IT IS BETA, BUT FEEL FREE TO USE IT! ALSO LET ME KNOW ABOUT ERRORS AND BUGS! 

--- 

## Contributing
#### As we won't exactly invite you into the project, feel free to leave pull requests, and we'll review them, whether or not we merge them. ;D
